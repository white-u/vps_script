#!/bin/bash

is_sh_ver=v1.0

. /etc/sing-box/sh/src/init.sh "$@"
